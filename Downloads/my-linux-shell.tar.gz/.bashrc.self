#!/usr/bin/env bash

# Path to the bash it configuration
export BASH_IT=$HOME/.bash_it

# Lock and Load a custom theme file
# location /.bash_it/themes/

# stars *5
#export BASH_IT_THEME='duru'
# stars *4
#export BASH_IT_THEME='modern'
#export BASH_IT_THEME='minimal'
#export BASH_IT_THEME='doubletime_multiline'
#export BASH_IT_THEME='standard'
#export BASH_IT_THEME='morris'
#export BASH_IT_THEME='doubletime_multiline_pyonly'
# stars *3
#export BASH_IT_THEME='font'
#export BASH_IT_THEME='simple'
#export BASH_IT_THEME='pro'
export BASH_IT_THEME='clean'
#export BASH_IT_THEME='dulcie'
#export BASH_IT_THEME='envy'
#export BASH_IT_THEME='iterate'
#export BASH_IT_THEME='purity'
# stars *2
#export BASH_IT_THEME='norbu'
#export BASH_IT_THEME='tylenol'
#export BASH_IT_THEME='tonotdo'
#export BASH_IT_THEME='gallifrey'
#export BASH_IT_THEME='bakke'
# stars *1
#export BASH_IT_THEME='rainbowbrite'
#export BASH_IT_THEME='sexy'
#export BASH_IT_THEME='zork'


# Your place for hosting Git repos. I use this for private repos.
export GIT_HOSTING='git@git.domain.com'

# Don't check mail when opening terminal.
unset MAILCHECK

# Change this to your console based IRC client of choice.
export IRC_CLIENT='irssi'

# Set this to the command you use for todo.txt-cli
export TODO="t"

# Set this to false to turn off version control status checking within the prompt for all themes
export SCM_CHECK=true

# Set vcprompt executable path for scm advance info in prompt (demula theme)
# https://github.com/xvzf/vcprompt
#export VCPROMPT_EXECUTABLE=~/.vcprompt/bin/vcprompt

# Load Bash It
source $BASH_IT/bash_it.sh

# aliases
alias vpn-add-fujitsu='sudo route -n add -net 164.69.0.0 -netmask 255.255.0.0 10.8.2.137'
alias vpn-del-fujitsu='sudo route -n delete -net 164.69.0.0'
alias vpn-add-tcl-shenzhen='sudo route -n add 192.168.8.40'

alias xview='export DISPLAY=`who am i | cut -f2 -d"(" | cut -f1 -d")"`:0.0'

alias lftp2fujitsu='lftp -p 3389 -u customer,aCC46qmi@ sftp://ftp2.thundersoft.com'
alias lftp2fj001='lftp -u ts-shenrui,ts-shenrui ftp://164.69.5.71'
alias lftp2netcast='lftp -p 21 -u netcast,netcast sftp://ftp2.thundersoft.com'

alias getp4script='p4 sync -f //TOOLS/BUILD/PerforceTool/LabelSyncTool/p4labeljobsync.pl'

alias ue='rm -rf ~/.idm/uex/*.*|rm -rf ~/.idm/uex/.dat |/usr/local/bin/uex &'

alias xiumian='sudo pm-hibernate' #休眠
alias guaqi='sudo pm-suspend' #挂起
alias shengdian='sudo pm-powersave' #省电模式

alias eth0re='sudo ifconfig eth0 down ; sleep 15 ; sudo ifconfig eth0 up'
alias add_dns='echo "nameserver 192.168.8.8" | sudo tee -a /etc/resolv.conf'
alias set_mac_fn='echo 2 | sudo tee /sys/module/hid_apple/parameters/fnmode'


alias getmail='fetchmail -a -f /home/lutx0528/.fetchmailrc'
alias mail-load='fetchmail -f /home/lutx0528/.fetchmailrc'
alias w3m='w3m -B -bookmark ~/.w3m/bookmark.html'

export PYTHONPATH=/usr/lib/python2.7/dist-packages:$PYTHONPATH
#export PYTHONPATH=/home/lutx0528/git-dir/tornado/maint:$PYTHONPATH
#export PYTHONPATH=/home/lutx0528/git-dir/click/click:$PYTHONPATH
export PATH=$HOME/bin:/usr/local/bin:$PATH
export TMUX_TMPDIR=~/.tmux-socket
export LC_ALL=en_US.UTF-8  
export LANG=en_US.UTF-8
#export SSH_CLIENT="164.69.155.30 48913 22"
#export SSH_CONNECTION="164.69.155.30 48913 164.69.155.29 22"
#export TERMINAL=
#export GOROOT=/usr/lib/go
unset GOROOT
export GOROOT=/usr/lib/go
unset GOPATH
export PATH=$PATH:GOROOT
go_local_lib="/home/lutx0528/fullstack/develop/github/GolangLibs"
#toolkit="/home/lutx0528/fullstack/develop/192.168/100.149/q-common/platform/vendor/ts/proprietary/toolkit/prebuilt_package"
#toolkit="/home/lutx0528/fullstack/develop/192.168/100.149/q-common/platform/vendor/ts/proprietary/toolkit/vendor_modules"
#toolkit="/home/lutx0528/fullstack/develop/192.168/100.149/q-common/platform/vendor/ts/proprietary/package_golang"
#export GOPATH=${go_local_lib}:${toolkit}
export GOPATH=${go_local_lib}
export GOARCH=amd64
export GOOS=linux

#export EDITOR="emacsclient -c"
#export EDITOR="emacsclient -nw"

#function emacs-server(){
#  if [ -f /home/lutx0528/emacs.pid ]; then kill `cat /home/lutx0528/emacs.pid` ; fi
#  rm -rf /home/lutx0528/emacs.pid
#  #/usr/bin/emacs --name emacs --daemon --no-desktop --kill \
#  #  -l ~/.emacs.d/init.el --eval '(server-start)' &>/dev/null &
#  /usr/bin/emacs --eval '(color-theme-sanityinc-tomorrow-eighties)' \
#    --daemon &>/dev/null &
#  echo "$!" > /home/lutx0528/emacs.pid
#}
#alias emacs="emacsclient -t"

#alias m-left='pointer = 3 2 1 5 4'
#alias m-right='pointer = 1 2 3 5 4'
#xmodmap -e "pointer = 1 2 3 5 4" # mouse like mac
#xmodmap -e "pointer = 3 2 1 5 4" # mouse like mac wiwth left hand
#xmodmap -e "pointer = 1 2 3 4 5" # mouse like window
#xmodmap -e "clear lock" #disable caps lock switch
#setxkbmap -option ""
#setxkbmap -option "caps:ctrl_modifier,ctrl:nocaps"

function tmux-load(){
  which tmux >/dev/null 2>&1 || exit 1
  tmux -L self start
  tmux -L self new -d -s hi -n sh
}

alias tmux-att='tmux -L self att'
alias tmux-www='tmux -L self att -t www'

#alias emacs="emacsclient"

##fetchmail -a -f /home/lutx0528/.fetchmailrc
alias ansible_ping_all="ansible ping-all -u root -m ping"
#alias windows="rdesktop -f -u lutx -p abc123 192.168.11.154"
alias windows="rdesktop -g 1280x1024 -u lutx -p abc123 192.168.11.154"
alias win_48="rdesktop -u work -p abc123 -g 1280x1024 192.168.11.48:3389"
alias win_mmc="rdesktop -u mmc -p thundersoft -g 1280x1024 192.168.100.33"
alias vbox='sudo modprobe vboxdrv && sudo virtualbox'
#alias dcompose='docker-compose -f /home/lutx0528/git-dir/FullStack/Docker/docker-compose.yml start'
alias dmysql="mysql -h192.168.9.5 -uadmin -p123456 -P3306 db_fms"
alias dtmysql="mysql -h192.168.9.5 -uadmin -p123456 -P3306 test_fms"
alias ssh_zhanghang="ssh frank@10.0.28.200"

#xal=$(ps aux | grep xautolock | grep -v grep | wc -l)
#if [ $xal == 0 ]; then
#  exec xautolock -time 3 -locker "gnome-screensaver-command --lock" &
#fi

export PATH=~/bin:$PATH
export PATH=~/bin:/home/lutx0528/bin:/sbin:/usr/local/bin:/usr/bin:/bin:/usr/games:GOROOT:GOROOT
export PATH=$PATH:/opt/gradle/gradle-5.6.4/bin

#alias jumpserver="ssh 192.168.17.24 -p 2222 -i ~/.ssh/lutx0528.pem"
alias jumpserver="ssh jump.thundersoft.com -p 2222 -i ~/.ssh/lutx0528.pem"
alias jumpserver="ssh jumpserver.thundersoft.com -p 2222 -i ~/.ssh/lutx0528.new.pem -l lutx0528"
alias add_default_route="sudo route add -net default gw 192.168.12.1"
alias ssh.192.168.17.14="ssh 192.168.17.14 -p 2222 -l root"


export VISUAL="/usr/bin/subl3"
export VISUAL="gvim"
export VISUAL="vim"
export EDITOR="vim"

source ~/.git-completion.bash

#xfwm4 --replace

export LANG=zh_CN.UTF-8
export LANGUAGE=zh_CN:en_US
export LC_CTYPE=en_US.UTF-8
export LC_ALL=zh_CN.UTF-8

export GTK_IM_MODULE=ibus
export XMODIFIERS=@im=ibus
export QT_IM_MODULE=ibus

#alias rancher="rancher --access-key DE92045203307DE78032 --secret-key q4ZBn92ujiizP29MW6XQL6CkEenEXDFpNUPxpZtu"

export RANCHER_URL=http://ai.thundersoft.com/v2-beta
#export RANCHER_ACCESS_KEY=DE92045203307DE78032
#export RANCHER_ACCESS_KEY=FC877AED0E3020B3F384
export RANCHER_ACCESS_KEY=CD53BED7CDABD0CA7F82
#export RANCHER_SECRET_KEY=q4ZBn92ujiizP29MW6XQL6CkEenEXDFpNUPxpZtu
#export RANCHER_SECRET_KEY=dMC2axF3Y5Kk4YYTkMq8BrTEbzPpm9pqGi9btakT
export RANCHER_SECRET_KEY=MmVh2gbLPYEnbFMovgthdwcuSxs74upwqAqW5zG1
export RANCHER_ENVIRONMENT=1a5
export RANCHER_ENVIRONMENT=1a25
export RANCHER_DOCKER_HOST=192.168.17.53
export RANCHER_CLIENT_DEBUG=false
export RANCHER_DOCKER_HOST=1h5

export ANDROID_HOME=/home/lutx0528/Downloads/sdk_gradle/android-sdk_355_linux-x86
