#!/bin/bash

ssh jumpserver.thundersoft.com -p 2222 -i ~/.ssh/lutx0528.new.pem -l lutx0528
